
<?php
session_start();
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (empty($email) || empty($password)) {
        echo "يرجى تعبئة جميع الحقول.";
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row["password"])) {
                $_SESSION["user_id"] = $row["id"];
                $_SESSION["full_name"] = $row["full_name"];
                header("Location: dashboard.php");
                exit();
            } else {
                echo "كلمة المرور غير صحيحة.";
            }
        } else {
            echo "البريد الإلكتروني غير مسجل.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول</title>
</head>
<body>
    <h2>تسجيل الدخول</h2>
    <form action="login.php" method="post">
        <label for="email">البريد الإلكتروني:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        <label for="password">كلمة المرور:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <button type="submit">دخول</button>
    </form>
</body>
</html>
