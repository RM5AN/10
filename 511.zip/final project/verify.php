<?php
require 'db.php';

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE verification_code = ?");
    $stmt->execute([$code]);
    $user = $stmt->fetch();

    if ($user) {
        $conn->prepare("UPDATE users SET is_verified = 1, verification_code = NULL WHERE id = ?")
             ->execute([$user['id']]);
        echo "تم تفعيل حسابك بنجاح! يمكنك تسجيل الدخول الآن.";
    } else {
        echo "رمز التحقق غير صالح.";
    }
}
?>