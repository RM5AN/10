<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $otp = rand(100000, 999999);

    $stmt = $conn->prepare("UPDATE users SET reset_otp = ? WHERE email = ?");
    $stmt->execute([$otp, $email]);

    $subject = "رمز إعادة تعيين كلمة المرور";
    $message = "رمز إعادة تعيين كلمة المرور الخاص بك هو: $otp";
    $headers = "From: no-reply@example.com";

    mail($email, $subject, $message, $headers);

    echo "تم إرسال رمز إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.";
}
?>