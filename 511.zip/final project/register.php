<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($password !== $confirm) {
        echo "❌ كلمات المرور غير متطابقة!";
        exit();
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (:name, :email, :pass)");
        $stmt->execute([
            ':name' => $full_name,
            ':email' => $email,
            ':pass' => $hashed_password
        ]);

        $user_id = $conn->lastInsertId();
        $_SESSION['user_id'] = $user_id;
        $_SESSION['full_name'] = $full_name;
        $_SESSION['email'] = $email;

        header("Location: index.php");
        exit();
    } catch (PDOException $e) {
        echo "فشل في إنشاء الحساب: " . $e->getMessage();
    }
}
?>
