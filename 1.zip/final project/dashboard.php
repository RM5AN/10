
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم</title>
</head>
<body>
    <h1>مرحباً بك يا <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h1>
    <p><a href="logout.php">تسجيل الخروج</a></p>
</body>
</html>
