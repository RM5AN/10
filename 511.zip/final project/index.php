<?php
session_start();
$isLoggedIn = isset($_SESSION['user_id']) && isset($_SESSION['full_name']);
$fullName = $_SESSION['full_name'] ?? '';
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
 <head>
  <meta charset="utf-8"/>
  <!-- يدعم جميع اللغات -->
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <!-- يضمن عرض المحتوى بشكل جيد على جميع الأجهزة -->
  <title>
   ShotSpot Store
  </title>
  <link href="style.css" rel="stylesheet"/>
  <script src="price-format.js">
  </script>
  <!-- إضافة مكتبة Font Awesome للأيقونات -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet"/>
  <!-- إضافة معالجة الأخطاء -->
  <script>
   // معالجة أخطاء تحميل الصور
        window.addEventListener('error', function(e) {
            if (e.target.tagName === 'IMG') {
                e.target.src = 'https://via.placeholder.com/150?text=ShotSpot';
            }
        }, true);
  </script>
  <style>
   /* الأنماط الأساسية */
        .hero-section {
            position: relative;
            height: 450px;
            overflow: hidden;
            padding: 30px 0;
        }
        .hero-slide {
            position: absolute;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
        }
        .hero-content {
            position: absolute;
            top: 50%;
            right: 10%;
            transform: translateY(-50%);
            color: white;
            text-align: right;
            max-width: 600px;
        }
        .hero-content h1 {
            font-size: 36px;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        .hero-content p {
            font-size: 16px;
            margin-bottom: 20px;
        }
        .hero-btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 25px;
        }
        
        /* نافذة العرض المنبثقة */
        .product-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.8);
            z-index: 1000;
            overflow-y: auto;
        }
        
        .modal-content {
            position: relative;
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            width: 80%;
            max-width: 900px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 28px;
            cursor: pointer;
            color: #333;
        }
        
        .product-images {
            display: flex;
            margin-bottom: 20px;
        }
        
        .main-image {
            width: 60%;
            padding: 10px;
        }
        
        .main-image img {
            width: 100%;
            height: auto;
            object-fit: contain;
            border-radius: 5px;
        }
        
        .thumbnails {
            width: 40%;
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding: 10px;
        }
        
        .thumbnail {
            width: 100%;
            height: 100px;
            cursor: pointer;
            border: 2px solid transparent;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .thumbnail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .thumbnail.active {
            border-color: #3498db;
        }
        
        .product-details {
            padding: 20px;
            border-top: 1px solid #eee;
        }
        
        .product-details h2 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #333;
        }
        
        .product-details p {
            font-size: 16px;
            line-height: 1.6;
            color: #666;
            margin-bottom: 15px;
        }
        
        .product-price {
            font-size: 24px;
            font-weight: bold;
            color: #222222;
            margin: 15px 0;
        }
        
        .product-actions {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .add-to-cart-btn, .add-to-favorites-btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .add-to-cart-btn {
            background-color: #3498db;
            color: white;
        }
        
        .add-to-favorites-btn {
            background-color: #f8f9fa;
            color: #333;
            border: 1px solid #ddd;
        }
        
        .add-to-cart-btn:hover {
            background-color: #2980b9;
        }
        
        .add-to-favorites-btn:hover {
            background-color: #f1f1f1;
        }
        
        /* الفئات المميزة */
        .featured-categories {
            padding: 40px 0;
            background-color: #f8f9fa;
        }
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }
        .category-card {
            position: relative;
            height: 250px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .category-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .category-content {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 15px;
            background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
            color: white;
        }
        
        /* فلاتر البحث */
        .filters-container {
            max-width: 1200px;
            margin: 0 auto 30px;
            padding: 0 15px;
        }
        
        /* العناوين الرئيسية */
        .section-title {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .section-title h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 8px;
        }
        
        /* تجاوب مع الشاشات الصغيرة */
        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 28px;
            }
            .hero-content p {
                font-size: 14px;
            }
            .category-grid {
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            }
            .category-card {
                height: 200px;
            }
        }

        .camera-bg {
            background-image: linear-gradient(rgba(255, 255, 255, 0.85), rgba(255, 255, 255, 0.85)), url('https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80');
            background-size: cover;
            background-position: center;
            padding: 120px 20px;
            text-align: center;
        }
        
        .shop-now-btn:hover {
            background-color: #2980b9;
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.25);
        }

        /* أنماط أقسام التصنيفات */
        .categories-section {
            margin-bottom: 40px;
            padding: 0 15px;
        }
        
        .category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 8px;
        }
        
        .category-header h2 {
            font-size: 22px;
            color: #333;
            margin: 0;
        }
        
        .view-all {
            color: #3498db;
            text-decoration: none;
            font-size: 14px;
        }
        
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 15px;
        }
        
        .category-card {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            background-color: white;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
        }

        .category-card-image {
            height: 180px;
            overflow: hidden;
        }
        
        .category-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .category-card:hover .category-card-image img {
            transform: scale(1.05);
        }
        
        .category-card-content {
            padding: 12px;
        }
        
        .category-card-content h3 {
            margin: 0 0 5px;
            font-size: 16px;
            color: #333;
        }
        
        .category-card-content p {
            margin: 0;
            font-size: 14px;
            color: #3498db;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .category-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .category-card-image {
                height: 140px;
            }
            
            .category-card-content h3 {
                font-size: 14px;
            }
        }
        
        @media (max-width: 480px) {
            .category-grid {
                grid-template-columns: 1fr;
            }
        }

        /* تعديل شريط الخدمات ليكون العناصر بالنص ومتقاربة */
        .services-ticker-container {
            position: sticky;
            top: 0;
            z-index: 10;
            width: 100%;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            background-color: #000000;
            padding: 7px 0;
        }
        
        .services-ticker {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0;
            overflow: hidden;
        }
        
        /* تنسيق المحتوى ليكون بالنص تماماً */
        .ticker-content {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        flex-wrap: nowrap;
        width: 100%;
        margin: 0 auto;
        animation: none !important;
        transform: none !important;
        overflow: hidden !important;
        white-space: nowrap;
    }
        
        .ticker-item {
            color: #ffffff;
            font-size: 12px;
            display: flex;
            align-items: center;
            white-space: nowrap;
            padding: 0;
        }
        
        .ticker-item i {
            margin-left: 3px;
            font-size: 12px;
        }
        
        /* تعديل للشاشات المتوسطة والصغيرة */
        @media (max-width: 992px) {
            .ticker-content {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        flex-wrap: nowrap;
        width: 100%;
        margin: 0 auto;
        animation: none !important;
        transform: none !important;
        overflow: hidden !important;
        white-space: nowrap;
    }
            
            .ticker-item {
                font-size: 11px;
            }
        }
        
        @media (max-width: 768px) {
            .ticker-content {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 15px;
        flex-wrap: nowrap;
        width: 100%;
        margin: 0 auto;
        animation: none !important;
        transform: none !important;
        overflow: hidden !important;
        white-space: nowrap;
    }
            
            .ticker-content::-webkit-scrollbar {
                display: none;
            }
        }

        /* أنماط قسم الأكثر شيوعاً */
        .most-popular {
            padding: 50px 0 40px;
            background-color: #f8f9fa !important;
            position: relative;
        }

        .most-popular:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(to right, #165b8a, #3498db, #165b8a);
        }

        .most-popular .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .most-popular-title {
            text-align: center;
            margin-bottom: 35px;
            position: relative;
        }

        .most-popular-title h2 {
            font-size: 28px;
            color: #333;
            font-weight: 600;
            margin-bottom: 12px;
            position: relative;
            display: inline-block;
            padding-bottom: 12px;
        }

        .most-popular-title h2:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 70px;
            height: 3px;
            background-color: #165b8a;
        }

        .most-popular-title p {
            font-size: 16px;
            color: #666;
            max-width: 700px;
            margin: 0 auto;
        }

        /* تنسيق البطاقات الأكثر شيوعاً */
        .popular-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .popular-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            position: relative;
        }

        .popular-card:hover {
            transform: translateY(-7px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
        }

        .popular-image {
            height: 180px;
            position: relative;
            overflow: hidden;
        }

        .popular-image img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            transition: transform 0.4s ease;
            padding: 10px;
        }

        .popular-card:hover .popular-image img {
            transform: scale(1.05);
        }

        .popular-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #165b8a;
            color: white;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }

        .popular-content {
            padding: 15px;
        }

        .popular-content h3 {
            font-size: 15px;
            font-weight: 600;
            margin-bottom: 10px;
            line-height: 1.4;
            height: 42px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
        }

        .price {
            font-weight: bold;
            color: #222222;
            font-size: 18px;
            margin-bottom: 8px;
            display: flex;
            flex-direction: row-reverse;
        }

        .sar-symbol {
            font-size: 16px;
            margin-right: 5px;
        }

        .rating {
            color: #ffc107;
            font-size: 14px;
        }

        .rating span {
            color: #777;
            margin-right: 5px;
        }

        /* أنماط النافذة المنبثقة */
        .popular-card {
            position: relative;
            overflow: hidden;
        }

        .product-popup {
            display: none;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            z-index: 10;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.3s ease;
            padding: 15px;
            transition: opacity 0.3s, transform 0.3s;
            overflow-y: auto;
        }

        .popular-card:hover .product-popup {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .popup-header {
            margin-bottom: 12px;
        }

        .popup-title {
            font-size: 16px;
            font-weight: 600;
        }

        .popup-close {
            position: absolute;
            top: 10px;
            left: 10px;
            background: none;
            border: none;
            font-size: 16px;
            cursor: pointer;
            color: #777;
        }

        .popup-details {
            margin-bottom: 15px;
        }

        .popup-detail {
            font-size: 13px;
            margin-bottom: 8px;
        }

        .popup-thumbs {
            display: flex;
            gap: 5px;
            margin-bottom: 15px;
        }

        .popup-thumb {
            width: 40px;
            height: 40px;
            border-radius: 5px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.2s;
        }

        .popup-thumb:hover {
            border-color: #165b8a;
        }

        .popup-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .popup-price {
            display: flex;
            align-items: center;
            color: #222222;
            font-weight: 700;
            font-size: 18px;
            margin-bottom: 10px;
            direction: rtl;
            flex-direction: row-reverse;
        }

        .popup-sar-symbol {
            margin-left: 5px;
        }

        .popup-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 5px;
        }

        .popup-availability {
            color: #4caf50;
            font-size: 12px;
            display: flex;
            align-items: center;
        }

        .popup-availability i {
            margin-left: 5px;
        }

        .popup-rating {
            color: #ffc107;
            font-size: 12px;
        }

        .popup-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .popup-actions button {
            flex: 1;
            padding: 8px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            font-family: 'Tajawal', sans-serif;
            transition: all 0.3s ease;
        }

        .popup-cart {
            background: #165b8a;
            color: white;
        }

        .popup-favorite {
            background: #f1f1f1;
            color: #333;
        }

        .popup-cart:hover {
            background: #134a6d;
        }

        .popup-favorite:hover {
            background: #e9ecef;
        }

        /* أنماط الفئات الدائرية */
        .category-circles {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .category-circle-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 180px;
            transition: all 0.4s ease;
        }
        
        .category-circle-item:hover {
            transform: scale(1.05);
        }
        
        .category-circle {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: inherit;
            transition: all 0.4s ease;
        }
        
        .circle-image {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            overflow: hidden;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 15px rgba(0,0,0,0.15);
            margin-bottom: 10px;
            border: 4px solid #fff;
            transition: all 0.4s ease;
            position: relative;
        }
        
        .circle-image:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle, rgba(255,255,255,0) 70%, rgba(52,152,219,0.15) 100%);
            border-radius: 50%;
            z-index: 1;
        }
        
        .category-circle:hover .circle-image {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(52,152,219,0.3);
            border-color: rgba(52,152,219,0.1);
        }
        
        .circle-image img {
            width: 75%;
            height: 75%;
            object-fit: contain;
            transition: all 0.5s ease;
            z-index: 2;
            position: relative;
        }
        
        .category-circle:hover .circle-image img {
            transform: scale(1.1);
        }
        
        .category-circle h3 {
            font-size: 16px;
            text-align: center;
            margin: 0 0 8px;
            color: #333;
            font-weight: bold;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .category-circle:hover h3 {
            color: #3498db;
        }
        
        .category-circle h3:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background-color: #3498db;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            transition: width 0.3s ease;
        }
        
        .category-circle:hover h3:after {
            width: 70%;
        }
        
        .circle-view-all {
            font-size: 14px;
            padding: 3px 12px;
        }
        
        .category-circle .category-icon {
            width: 25px;
            height: 25px;
            font-size: 12px;
        }
        
        /* تعديلات التجاوب للشاشات المختلفة */
        @media (max-width: 992px) {
            .category-circles {
                gap: 20px;
            }
            
            .category-circle-item {
                width: 160px;
            }
            
            .circle-image {
                width: 150px;
                height: 150px;
            }
        }
        
        @media (max-width: 768px) {
            .category-circles {
                gap: 15px;
            }
            
            .category-circle-item {
                width: 140px;
            }
            
            .circle-image {
                width: 130px;
                height: 130px;
            }
            
            .category-circle h3 {
                font-size: 14px;
            }
            
            .circle-view-all {
                font-size: 12px;
                padding: 2px 10px;
            }
        }
        
        @media (max-width: 480px) {
            .category-circle-item {
                width: 120px;
            }
            
            .circle-image {
                width: 110px;
                height: 110px;
            }
            
            .category-circle h3 {
                font-size: 12px;
            }
            
            .category-circle .category-icon {
                width: 20px;
                height: 20px;
                font-size: 10px;
            }
        }

        /* أنماط قسم تأجير المعدات على غرار صفحة الخدمات */
        .rental-section {
            background-color: #eee;
            padding: 50px 0;
        }
        
        .rental-container {
            max-width: 900px; /* تقليل العرض لتركيز المحتوى */
            margin: 0 auto;
            padding: 0 15px;
        }

        .rental-card {
            background-color: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 6px 18px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-align: center;
            display: flex;
            flex-direction: row;
            width: 90%;
            max-width: 900px;
            margin: 0 auto;
        }

        .rental-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .rental-card-image {
            width: 40%;
            height: auto;
            min-height: 220px;
            overflow: hidden;
            position: relative;
            background-color: #f7f7f7;
        }
        
        .rental-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }

        .rental-card:hover .rental-card-image img {
            transform: scale(1.08);
        }

        .rental-icon {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(52, 152, 219, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 32px;
            z-index: 2;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .rental-card-image:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.2);
            z-index: 1;
        }

        .rental-card-content {
            padding: 25px 30px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            width: 60%;
            text-align: right;
        }

        .rental-card-content h3 {
            font-size: 20px;
            color: #333;
            margin-bottom: 15px;
            font-weight: bold;
        }
        
        .rental-card-content p {
            font-size: 15px;
            color: #666;
            margin-bottom: 20px;
            line-height: 1.6;
            flex-grow: 1;
        }
        
        .rental-btn {
            width: 60%;
            padding: 12px 25px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: block;
            margin: 0 auto;
            margin-top: 15px;
            text-align: center;
        }
        
        .rental-btn:hover {
            background-color: #2980b9;
            transform: translateY(-3px);
        }

        .rental-grid {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }

        .rental-title {
            text-align: center;
            margin-bottom: 40px;
        }

        .rental-title h2 {
            font-size: 30px;
            margin-bottom: 15px;
            color: #165b8a;
        }

        .rental-title p {
            font-size: 16px;
            color: #666;
            max-width: 700px;
            margin: 0 auto;
        }

        @media (max-width: 992px) {
            .rental-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .rental-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .rental-card {
                flex-direction: column;
                width: 95%;
            }
            
            .rental-card-image {
                width: 100%;
                min-height: 180px;
            }
            
            .rental-card-content {
                width: 100%;
                padding: 20px 15px;
            }
            
            .rental-icon {
                width: 70px;
                height: 70px;
                font-size: 28px;
            }
        }

        /* حاوية زر تصفح جميع المنتجات */
.view-all-btn-container {
    text-align: center;
    margin: 40px 0 50px;
    position: relative;
    border: none !important;
    background: none !important;
    box-shadow: none !important;
    clear: both;
}

/* إزالة أي تأثير قبل الزر */
.view-all-btn-container::before {
    content: none !important;
    display: none !important;
    background: none !important;
}

/* تنسيق زر تصفح جميع المنتجات */
.view-all-products-btn {
    display: inline-block;
    margin: 0 auto;
    background: linear-gradient(to bottom, #3498db, #2980b9);
    color: white;
    padding: 15px 40px;
    font-size: 18px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: bold;
    box-shadow: 0 6px 15px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
    border: 2px solid transparent; /* حدود شفافة */
    outline: none; /* إخفاء الحدود الخارجية عند التركيز */
    position: relative;
    z-index: 5;
    min-width: 220px;
    letter-spacing: 0.5px;
}

/* تأثير hover للزر */
.view-all-products-btn:hover {
    background: linear-gradient(to bottom, #2980b9, #3498db);
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
    border: 2px solid #2980b9;
    filter: brightness(1.1);
    text-decoration: none;
    color: white;
}

/* إزالة تأثير التركيز */
.view-all-products-btn:focus {
    outline: none;
    text-decoration: none;
}

        
        /* تنسيق عنوان تصفح المنتجات */
        .categories-title {
            text-align: center;
            margin-bottom: 30px;
            position: relative;
        }

        .categories-title h2 {
            font-size: 30px;
            color: #333;
            margin-bottom: 15px;
            position: relative;
            display: inline-block;
            padding-bottom: 10px;
        }

        .categories-title h2:after {
            display: none;
        }

        .categories-title p {
            font-size: 16px;
            color: #666;
            max-width: 700px;
            margin: 0 auto 20px;
        }

        /* تحسين مظهر قسم الفئات */
        .category-circles {
            margin-top: 30px;
            margin-bottom: 40px;
        }

        /* تنسيق عام للأسعار - تغيير اللون إلى أسود داكن */
        .price, .product-price, .cart-price, .summary-price, .total-price {
            color: #222222; /* تغيير اللون من #165b8a إلى #222222 (أسود داكن) */
            font-family: 'Tajawal', sans-serif;
            font-size: 18px;
            font-weight: 700; /* زيادة سماكة الخط لتحسين القراءة */
            display: flex;
            align-items: center;
            justify-content: center;
            direction: ltr;
        }

        /* تطبيق شعار الريال على كل أسعار الموقع */
        .price span, .product-price span, .cart-price span, .summary-price span, .total-price span {
            margin-left: 5px;
        }

        /* تنسيقات خاصة للأسعار المختلفة */
        .product-details .product-price {
            font-size: 24px;
            margin: 15px 0;
            display: flex;
            justify-content: center;
            color: #222222; /* تأكيد تطبيق اللون الجديد */
        }

        /* إضافة خط تحت السعر في صفحة تفاصيل المنتج */
        .product-details .product-price {
            position: relative;
            padding-bottom: 5px;
        }

        .product-details .product-price:after {
            content: "";
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 30%;
            height: 2px;
            background-color: #222222;
            opacity: 0.5;
        }

        /* تنسيق سعر بطاقة المنتج في الصفحة الرئيسية */
        .product-card .price {
            color: #222222;
            font-weight: 700;
            margin-top: 5px;
        }

        /* تنسيق أسعار المقارنة أو الخصومات */
        .old-price {
            color: #777777;
            text-decoration: line-through;
            margin-left: 8px;
            font-size: 14px;
            font-weight: normal;
        }

        /* تثبيت الهيدر ومنع الرجفة */
        header {
            background: var(--gray-100);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            height: auto;
            min-height: 70px;
            transition: none;
        }

        nav {
            max-width: 1200px;
            margin: 0 auto;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            position: relative;
            height: 100%;
        }

        /* منع انتقال العناصر في الهيدر */
        .logo, .main-menu, .header-actions {
            position: relative;
            transform: none;
            transition: none;
        }

        /* أنماط عرض عدد المنتجات في السلة والمفضلة */
        .cart-count, .wishlist-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #e74c3c;
            color: white;
            font-size: 10px;
            width: 16px;
            height: 16px;
            display: none;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-weight: bold;
        }

        .cart-icon, .heart-icon {
            position: relative;
        display: inline-block;
        }

        /* تنسيق تأثير النبض */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        .pulse {
            animation: pulse 0.5s ease-in-out;
    }

    /* أضف هذه الأنماط داخل وسم style في ملف index.html */
    .search-results {
        position: absolute;
        top: 100%;
        right: 0;
        width: 300px;
        max-height: 400px;
        overflow-y: auto;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 1000;
        display: none;
    }

    .search-results ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .search-results li {
        padding: 12px;
        border-bottom: 1px solid #eee;
        display: flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .search-results li:last-child {
        border-bottom: none;
    }

    .search-results li:hover {
        background-color: #f5f5f5;
    }

    .search-results img {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border-radius: 4px;
    }

    .result-info {
        flex: 1;
    }

    .result-info h4 {
        margin: 0 0 5px;
        font-size: 14px;
        color: #333;
    }

    .result-info p {
        margin: 0;
        font-size: 13px;
        color: #165b8a;
        font-weight: bold;
    }

    /* أنماط رسائل الإشعارات */
    .toast-container {
        position: fixed;
        top: 20px;
        left: 20px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .toast-message {
        background-color: white;
        color: #333;
        padding: 12px 15px;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 14px;
        transform: translateX(-110%);
        transition: transform 0.3s ease;
        max-width: 300px;
    }

    .toast-message.show {
        transform: translateX(0);
    }

    .toast-message i {
        font-size: 18px;
    }

    .toast-message.success i {
        color: #2ecc71;
    }

    .toast-message.error i {
        color: #e74c3c;
    }

    .toast-message.info i {
        color: #3498db;
    }

    .toast-message.wishlist i {
        color: #e74c3c;
    }

    .toast-message.cart i {
        color: #3498db;
    }

    .toast-close {
        margin-left: auto;
            background: none;
            border: none;
        color: #777;
            cursor: pointer;
        padding: 0;
        font-size: 14px;
    }
  
.account-menu {
    z-index: 9999 !important;
}
  
.search-container + div[style*="position:absolute"] {
    display: none !important;
}
  </style>
 </head>
 <body>
  <!-- Header -->
  <header>
   <nav>
    <div class="logo">
     <a href="index.html">
      <img alt="ShotSpot Logo" src="shotspot-logo.png-removebg-preview.png" style="height: 45px;"/>
      <span style="margin-left: -15px; font-size: 26px;">
       ShotSpot
      </span>
      <img alt="Camera Logo" src="camera-logo.png" style="height: 80px; margin-right: -25px; margin-left: -15px; position: relative; z-index: 1;"/>
     </a>
    </div>
    <div class="main-menu">
     <a class="active" href="index.html">
      الصفحة الرئيسية
     </a>
     <a href="about.html">
      من نحن
     </a>
     <a href="services.html">
      خدماتنا
     </a>
     <a href="contact.html">
      تواصل معنا
     </a>
    </div>
    <div class="icons-group">
     
<div class="account-dropdown">
    <a href="<?php echo $isLoggedIn ? 'account.html' : 'login.html'; ?>" class="user-icon active">
        <i class="fas fa-user"></i>
    </a>
    <div class="account-menu">
        <?php if ($isLoggedIn): ?>
            <a href="account.html">حسابي</a>
            <a href="logout.php">تسجيل الخروج</a>
        <?php else: ?>
            <a href="login.html">تسجيل الدخول</a>
            <a href="register.html">حساب جديد</a>
            <a href="rent-request.html">طلب تأجير</a>
        <?php endif; ?>
    </div>
</div>

    <a class="heart-icon" href="favorites.html">
     <i class="far fa-heart">
     </i>
     <span class="wishlist-count">
      0
     </span>
    </a>
    <a class="cart-icon" href="cart.html">
     <i class="fas fa-shopping-cart">
     </i>
     <span class="cart-count">
      0
     </span>
    </a>
    <div class="search-container">
     <input id="search" placeholder="ابحث عن منتجات..." type="text"/>
     <i class="fas fa-search search-icon">
     </i>
    </div>
    <div id="search-results" style="background:white; position:absolute; z-index:10000; width:100%; max-width:300px;">
    </div>
   </nav>
  </header>
  <!-- شريط للخدمات -->
  <div class="services-ticker-container">
   <div class="services-ticker">
    <div class="ticker-content">
     <div class="ticker-item">
      <i class="fas fa-truck">
      </i>
      توصيل سريع لجميع مناطق المملكة
     </div>
     <div class="ticker-item">
      <i class="fas fa-shield-alt">
      </i>
      ضمان على جميع المنتجات
     </div>
     <div class="ticker-item">
      <i class="fas fa-headset">
      </i>
      دعم فني على مدار الساعة
     </div>
     <div class="ticker-item">
      <i class="fas fa-tools">
      </i>
      خدمات صيانة احترافية
     </div>
     <div class="ticker-item">
      <i class="fas fa-graduation-cap">
      </i>
      دورات تدريبية في التصوير
     </div>
     <div class="ticker-item">
      <i class="fas fa-camera">
      </i>
      أحدث معدات التصوير
     </div>
     <div class="ticker-item">
      <i class="fas fa-percent">
      </i>
      عروض وخصومات دورية
     </div>
    </div>
   </div>
  </div>
  <!-- Hero Section -->
  <section class="hero-section">
   <div class="hero-container">
    <div class="hero-image-box">
     <img alt="معدات تصوير احترافية" src="https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;w=1000&amp;q=80"/>
    </div>
    <div class="hero-action-box">
     <h2>
      متجر ShotSpot
     </h2>
     <p>
      المتجر الأول لمعدات التصوير الاحترافية
     </p>
     <a class="shop-now-btn" href="all-products.html">
      تسوق الآن
     </a>
    </div>
   </div>
  </section>
  <style>
   .hero-section {
        padding: 30px 0;
        background-color: #eee;
    }
    
    .hero-container {
        max-width: 1100px;
        margin: 0 auto;
            display: flex;
        flex-direction: row-reverse;
        gap: 20px;
        height: 380px;
    }
    
    .hero-image-box {
        flex: 3;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .hero-image-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .hero-action-box {
        flex: 1;
        background-color: #fff;
        border-radius: 10px;
        padding: 25px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .hero-action-box h2 {
        font-size: 26px;
        color: #333;
        margin-bottom: 12px;
    }
    
    .hero-action-box p {
        font-size: 15px;
        color: #666;
        margin-bottom: 25px;
    }
    
    .shop-now-btn {
        display: inline-block;
        background-color: #3498db;
        color: white;
        padding: 10px 25px;
        font-size: 16px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: bold;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        transition: all 0.3s ease;
    }
    
    .shop-now-btn:hover {
        background-color: #2980b9;
        transform: translateY(-3px);
    }
    
    /* تعديل للشاشات الصغيرة */
    @media (max-width: 768px) {
        .hero-container {
            flex-direction: column;
            height: auto;
        }
        
        .hero-image-box {
            height: 250px;
        }
        
        .hero-action-box {
            padding: 20px;
        }
    }
  </style>
  <section id="product-categories" style="padding: 40px 0 20px; background-color: #eee !important;">
   <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 15px;">
    <div class="categories-title">
     <h2>
      تصفح منتجاتنا
     </h2>
     <p>
      اختر من مجموعتنا الواسعة من معدات التصوير الاحترافية بأفضل الأسعار وأعلى جودة
     </p>
    </div>
    <!-- فئات المنتجات الدائرية بدون أيقونات -->
    <div class="category-circles">
     <div class="category-circle-item">
      <a class="category-circle" href="all-cameras.html">
       <div class="circle-image">
        <img alt="الكاميرات" src="Fujifilm-X-T30 (1).jpg"/>
       </div>
       <h3>
        الكاميرات
       </h3>
      </a>
     </div>
     <div class="category-circle-item">
      <a class="category-circle" href="all-lenses.html">
       <div class="circle-image">
        <img alt="العدسات" src="sigma 24-70 (1).jpg"/>
       </div>
       <h3>
        العدسات
       </h3>
      </a>
     </div>
     <div class="category-circle-item">
      <a class="category-circle" href="all-accessories.html">
       <div class="circle-image">
        <img alt="اكسسوارات التصوير" src="Camera Tripod Stand 170cm (1).jpg"/>
       </div>
       <h3>
        اكسسوارات التصوير
       </h3>
      </a>
     </div>
     <div class="category-circle-item">
      <a class="category-circle" href="all-audio.html">
       <div class="circle-image">
        <img alt="معدات الصوت" src="Rode VideoMic Pro (1).jpg"/>
       </div>
       <h3>
        معدات الصوت
       </h3>
      </a>
     </div>
     <div class="category-circle-item">
      <a class="category-circle" href="all-bags.html">
       <div class="circle-image">
        <img alt="حقائب وأدوات تنقل" src="Lowepro ProTactic 450 AW II (1).jpg"/>
       </div>
       <h3>
        حقائب وأدوات تنقل
       </h3>
      </a>
     </div>
    </div>
   </div>
  </section>
  <!-- زر تصفح جميع المنتجات -->
  <div class="view-all-btn-container">
   <a class="view-all-products-btn" href="all-products.html">
    تصفح جميع المنتجات
    <i class="fas fa-arrow-left">
    </i>
   </a>
  </div>
  <section class="most-popular">
   <div class="container">
    <div class="most-popular-title">
     <h2>
      الأكثر شيوعاً
     </h2>
     <p>
      تصفح مجموعة من أفضل منتجاتنا وأكثرها شعبية لدى عملائنا
     </p>
    </div>
    <div class="popular-grid">
     <a class="popular-card">
      <div class="popular-image">
       <img alt="كاميرا X-T30ll" src="Fujifilm-X-T30 (1).jpg"/>
       <span class="popular-badge">
        الأكثر مبيعاً
       </span>
      </div>
      <div class="popular-content">
       <h3>
        كاميرا X-T30ll بدقة 26 ميجابكسل
       </h3>
       <div class="price"><span>٢,٥٨٠</span>
        <span class="sar-symbol"></span>
       </div>
       <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
        <span>(٤٥)</span>
       </div>
       <button class="view-product-btn" type="button" onclick="openProductDetails('camera-xt30')">عرض المنتج</button>
      </div>
     </a>
     <a class="popular-card">
      <div class="popular-image">
       <img alt="عدسة سيجما" src="sigma 24-70 (1).jpg"/>
       <span class="popular-badge">
        مميز
       </span>
      </div>
      <div class="popular-content">
       <h3>
        عدسة سيجما بزاوية واسعة
       </h3>
       <div class="price"><span>٤,٨٠٠</span>
        <span class="sar-symbol"></span>
       </div>
       <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <span>(٣٢)</span>
       </div>
       <button class="view-product-btn" type="button">
        عرض المنتج
       </button>
      </div>
     </a>
     <a class="popular-card">
      <div class="popular-image">
       <img alt="ميكروفون Rode VideoMic Pro+" src="Rode VideoMic Pro (1).jpg"/>
       <span class="popular-badge">
        جديد
       </span>
      </div>
      <div class="popular-content">
       <h3>
        ميكروفون Rode VideoMic Pro+
       </h3>
       <div class="price"><span>١٢٩٩</span>
        <span class="sar-symbol"></span>
       </div>
       <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
        <span>(٣٥)</span>
       </div>
       <button class="view-product-btn" type="button">
        عرض المنتج
       </button>
      </div>
     </a>
     <a class="popular-card">
      <div class="popular-image">
       <img alt="حقيبة ظهر لوبرو" src="Lowepro ProTactic 450 AW II (1).jpg"/>
       <span class="popular-badge">
        توفير ٢٠٪
       </span>
      </div>
      <div class="popular-content">
       <h3>
        حقيبة ظهر Lowepro ProTactic 450 AW II
       </h3>
       <div class="price"><span>٧٩٩</span>
        <span class="sar-symbol"></span>
       </div>
       <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
        <span>(٣٨)</span>
       </div>
       <button class="view-product-btn" type="button">
        عرض المنتج
       </button>
      </div>
     </a>
    </div>
   </div>
  </section>
  <!-- قسم تأجير المعدات على  -->
  <section class="rental-section">
   <div class="rental-container">
    <div class="rental-title">
     <h2>
      خدمات التأجير
     </h2>
     <p>
      انضم إلى منصة ShotSpot لتأجير معدات التصوير الاحترافية
     </p>
    </div>
    <div class="rental-grid">
     <div class="rental-card">
      <div class="rental-card-image">
       <img alt="تأجير معدات التصوير" src="https://images.unsplash.com/photo-1520390138845-fd2d229dd553?ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=800&amp;q=80"/>
       <div class="rental-icon">
        <i class="fas fa-camera">
        </i>
       </div>
      </div>
      <div class="rental-card-content">
       <h3>
        أجّر معداتك
       </h3>
       <p>
        حوّل معدات التصوير الخاصة بك إلى مصدر دخل إضافي عن طريق تأجيرها للمصورين المحترفين والهواة. نوفر لك منصة آمنة لعرض معداتك والتواصل مع المهتمين، مع تأمين شامل ودعم فني على مدار الساعة.
       </p>
       <a class="rental-btn" href="rent-request.html">
        سجّل معداتك
       </a>
      </div>
     </div>
    </div>
   </div>
  </section>
  <!-- Footer -->
  <footer>
   <div class="footer-content">
    <div class="footer-section">
     <h3>
      ShotSpot
     </h3>
     <p style="font-size: 14px;">
      متجر متخصص في بيع أحدث الكاميرات وملحقاتها بأفضل الأسعار. نقدم مجموعة واسعة من المنتجات الأصلية مع ضمان شامل.
     </p>
    </div>
    <div class="footer-section">
     <h3>
      روابط سريعة
     </h3>
     <ul>
      <li>
       <a href="index.html">
        الرئيسية
       </a>
      </li>
      <li>
       <a href="all-products.html">
        المنتجات
       </a>
      </li>
      <li>
       <a href="about.html">
        من نحن
       </a>
      </li>
      <li>
       <a href="contact.html">
        تواصل معنا
       </a>
      </li>
     </ul>
    </div>
    <div class="footer-section">
     <h3>
      اتصل بنا
     </h3>
     <p>
      <i class="fas fa-phone">
      </i>
      +966 11 234 5678
     </p>
     <p>
      <i class="fas fa-envelope">
      </i>
      info@ShotSpot.sa
     </p>
    </div>
    <div class="footer-section">
     <h3>
      وسائل الدفع
     </h3>
     <div class="payment-methods-footer">
      <img alt="مدى" src="https://pbs.twimg.com/media/FNZXGQ6WQAgijTF.jpg" style="height: 25px; background-color: white; padding: 3px; border-radius: 3px; margin-left: 6px;"/>
      <img alt="Visa" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png.png" style="height: 25px; background-color: white; padding: 3px; border-radius: 3px;"/>
     </div>
    </div>
   </div>
   <div class="social-links">
    <a href="#">
     <i class="fab fa-youtube">
     </i>
    </a>
    <a href="#">
     <i class="fab fa-instagram">
     </i>
    </a>
    <a href="#">
     <i class="fab fa-twitter">
     </i>
    </a>
    <a href="#">
     <i class="fab fa-facebook">
     </i>
    </a>
   </div>
   <div class="footer-bottom">
    <p>
     © 2024 ShotSpot. جميع الحقوق محفوظة.
    </p>
   </div>
  </footer>
  <!-- نافذة عرض تفاصيل المنتج -->
  <div class="product-modal" id="productModal">
   <div class="modal-content">
    <span class="close-modal">
     ×
    </span>
    <div class="product-images">
     <div class="main-image">
      <img alt="حقيبة كاميرا" id="mainProductImage" src="11125 Case (1)-220x220 camera case for canon powershot G7X.jpg"/>
     </div>
     <div class="thumbnails">
      <div class="thumbnail active" onclick="changeImage('11125 Case (1)-220x220 camera case for canon powershot G7X.jpg')">
       <img alt="حقيبة كاميرا - صورة 1" src="11125 Case (1)-220x220 camera case for canon powershot G7X.jpg"/>
      </div>
      <div class="thumbnail" onclick="changeImage('https://www.camtime.sa/image/cache/catalog/00004/11125%20Case%20(2)-800x1000.jpg')">
       <img alt="حقيبة كاميرا - صورة 2" src="https://www.camtime.sa/image/cache/catalog/00004/11125%20Case%20(2)-800x1000.jpg"/>
      </div>
      <div class="thumbnail" onclick="changeImage('https://www.camtime.sa/image/cache/catalog/00004/11125%20Case%20(3)-432x432.jpg')">
       <img alt="حقيبة كاميرا - صورة 3" src="https://www.camtime.sa/image/cache/catalog/00004/11125%20Case%20(3)-432x432.jpg"/>
      </div>
      <div class="thumbnail" onclick="changeImage('https://www.camtime.sa/image/cache/catalog/00004/11125%20Case%20(4)-800x1000.jpg')">
       <img alt="حقيبة كاميرا - صورة 4" src="https://www.camtime.sa/image/cache/catalog/00004/11125%20Case%20(4)-800x1000.jpg"/>
      </div>
     </div>
    </div>
    <div class="product-details">
     <h2>
      حقيبة كاميرا
     </h2>
     <div class="product-price">
      ٨٠ ﷼
     </div>
     <div class="camera-actions">
      <button class="add-to-cart">
       <i class="fas fa-shopping-cart">
       </i>
       إضافة للسلة
      </button>
      <button class="add-to-favorites">
       <i class="fas fa-heart">
       </i>
      </button>
     </div>
     <a class="view-details-btn" href="all-cameras.html">
      <i class="fas fa-search-plus">
      </i>
      عرض التفاصيل
     </a>
     <p>
      حقيبة كاميرا - صندوق الكاميرا الرقمية متوافق مع العديد من الماركات مثل: Zheozeig، Duluvulu، TEBNGIHNM، Oiadek، KVUTCIEIN، Femivo، Fulealfly، AiTechny، VAHOIALD، Bifevsr، IWEUKJLO، Jumobuis للكاميرات الرقمية بدقة 4K.
     </p>
     <p>
      حقيبة كاميرا الفيديو مناسبة أيضًا لكاميرا كانون باورشوت الرقمية [G7 X Mark II/III] وكاميرات XNSIAKXA للتصوير الفوتوغرافي. الأبعاد الداخلية لحامل كانون G7X هي 5.1 × 2.9 × 1.8 بوصة. (حقيبة حمل فقط، لا تشمل الكاميرا)
     </p>
     <div class="product-actions">
      <button class="add-to-cart-btn" onclick="addToCartFromModal()">
       <i class="fas fa-shopping-cart">
       </i>
       إضافة إلى السلة
      </button>
      <button class="add-to-favorites-btn" onclick="addToFavoritesFromModal()">
       <i class="fas fa-heart">
       </i>
       إضافة إلى المفضلة
      </button>
     </div>
    </div>
   </div>
  </div>
  <script src="all-products.js">
  </script>
  <script>
   document.addEventListener('DOMContentLoaded', function() {
            // إضافة مستمعي أحداث لأزرار إغلاق النوافذ المنبثقة
            document.querySelectorAll('.popup-close').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const popup = this.closest('.product-popup');
                    popup.style.display = 'none';
                });
            });

            // إضافة مستمعي أحداث لأزرار النوافذ المنبثقة
            document.querySelectorAll('.popup-cart').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    alert('تمت إضافة المنتج إلى سلة التسوق');
                });
            });

            document.querySelectorAll('.popup-favorite').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    alert('تمت إضافة المنتج إلى المفضلة');
                    this.innerHTML = '<i class="fas fa-heart" style="color: #e74c3c;"></i> تمت الإضافة';
                });
            });

            // منع انتقال الضغط على البوب أب إلى بطاقة المنتج
            document.querySelectorAll('.product-popup').forEach(popup => {
                popup.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
        });
    });

    // إضافة كود جافاسكريبت لتفعيل أزرار السلة والمفضلة
    document.addEventListener('DOMContentLoaded', function() {
        // تفعيل أزرار إضافة للسلة
        document.querySelectorAll('.add-to-cart-btn, .add-to-cart').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = Math.floor(Math.random() * 1000);
                const productName = document.querySelector('.product-details h2')?.textContent || 'منتج';
                const productPrice = document.querySelector('.product-price')?.textContent.replace(/[^\d]/g, '') || '100';
                const productImage = document.querySelector('.main-image img')?.src || '';
                
                // استخدام الدالة الموجودة سابقاً
                addToCart(productId, productName, productPrice, productImage);
                
                // إظهار رسالة نجاح
                showToast('تمت إضافة المنتج إلى السلة بنجاح!', 'success', 'cart');
            });
        });
        
        // تفعيل أزرار إضافة للمفضلة
        document.querySelectorAll('.add-to-favorites-btn, .wishlist-btn').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = Math.floor(Math.random() * 1000);
                const productName = document.querySelector('.product-details h2')?.textContent || 'منتج';
                const productPrice = document.querySelector('.product-price')?.textContent.replace(/[^\d]/g, '') || '100';
                const productImage = document.querySelector('.main-image img')?.src || '';
                
                // استخدام الدالة الموجودة سابقاً
                toggleWishlist(productId, productName, productPrice, productImage);
                
                // إظهار رسالة نجاح
                showToast('تمت إضافة المنتج إلى المفضلة', 'success', 'wishlist');
            });
        });
    });

    // تفعيل وظيفة البحث
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.querySelector('.search-container input');
        const searchIcon = document.querySelector('.search-icon');
        
        if (searchInput && searchIcon) {
            // إضافة حدث للبحث عند الضغط على Enter
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    performSearch();
                }
            });
            
            // إضافة حدث للبحث عند النقر على أيقونة البحث
            searchIcon.addEventListener('click', function() {
                performSearch();
            });
            
            function performSearch() {
                const searchTerm = searchInput.value.trim();
                if (searchTerm.length > 0) {
                    // عرض نتائج البحث
                    showSearchResults(searchTerm);
                }
            }
            
            function showSearchResults(searchTerm) {
                // إنشاء عنصر لعرض نتائج البحث
                let searchResults = document.querySelector('.search-results');
                if (!searchResults) {
                    searchResults = document.createElement('div');
                    searchResults.className = 'search-results';
                    document.querySelector('.search-container').appendChild(searchResults);
                }
                
                // عرض نتائج وهمية للتوضيح
                searchResults.innerHTML = `
                    <ul>
                        <li>
                            <img src="Fujifilm-X-T30 (1).jpg" alt="نتيجة البحث">
                            <div class="result-info">
                                <h4>كاميرا ${searchTerm}</h4>
                                <p>1200 ر.س</p>
                            </div>
                        </li>
                        <li>
                            <img src="canon.png" alt="نتيجة البحث">
                            <div class="result-info">
                                <h4>عدسة ${searchTerm}</h4>
                                <p>850 ر.س</p>
                            </div>
                        </li>
                    </ul>
                `;
                
                // إظهار نتائج البحث
                searchResults.style.display = 'block';
                
                // إغلاق نتائج البحث عند النقر خارجها
                document.addEventListener('click', function closeResults(e) {
                    if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                        searchResults.style.display = 'none';
                        document.removeEventListener('click', closeResults);
                    }
                });
            }
        }
    });
  </script>
  <!-- أضف هذا السطر قبل إغلاق وسم body مباشرة -->
  <script src="app.js">
  </script>
  <script src="script.js">
  </script>
  <!-- إصلاح مشكلة عدم القدرة على النقر على الروابط -->
  <script>
   document.addEventListener('DOMContentLoaded', function() {
        // إضافة تنسيقات CSS المطلوبة
        const fixInteractionStyles = document.createElement('style');
        fixInteractionStyles.textContent = `
            /* ضمان استقبال النقر على جميع العناصر التفاعلية */
            a, button, .logo, .main-menu a, .icons-group a, .search-container, .shop-now-btn,
            .product-card, .add-to-cart, .wishlist-btn, input, select, .category-circle {
                pointer-events: auto !important;
                cursor: pointer !important;
                position: relative !important;
                z-index: 10 !important;
            }
            
            /* إلغاء أي عناصر overlay تغطي الصفحة */
            .modal, .overlay, .product-modal, .toast-container {
                position: absolute !important;
                height: auto !important;
                width: auto !important;
                display: none !important;
            }
            
            /* إعادة ضبط تنسيقات header */
            header {
                position: relative !important;
                height: auto !important;
                min-height: 80px !important;
                z-index: 100 !important;
                top: auto !important;
                left: auto !important;
                width: 100% !important;
            }
            
            /* إعادة ضبط أي عناصر fixed مخفية */
            body::before, body::after {
                display: none !important;
                content: none !important;
            }
            
            /* التأكد من عدم وجود عناصر تغطي الصفحة كاملة */
            body > div:not(.main-content):not(header):not(footer) {
                position: relative !important;
                height: auto !important;
                max-height: none !important;
            }
            
            /* إزالة أي تنسيقات قد تمنع التفاعل */
            * {
                touch-action: auto !important;
            }
        `;
        document.head.appendChild(fixInteractionStyles);
        
        // إصلاح وسوم alt في بعض الصفحات
        document.querySelectorAll('alt').forEach(brokenTag => {
            const newImg = document.createElement('img');
            newImg.src = "camera-logo.png";
            
            // نقل جميع الخصائص
            Array.from(brokenTag.attributes).forEach(attr => {
                newImg.setAttribute(attr.name, attr.value);
            });
            
            // استبدال العنصر
            if (brokenTag.parentNode) {
                brokenTag.parentNode.replaceChild(newImg, brokenTag);
            }
        });
        
        // التأكد من أن كل الروابط تحتوي على href
        document.querySelectorAll('a').forEach(link => {
            if (!link.getAttribute('href')) {
                if (link.closest('.logo')) {
                    link.setAttribute('href', 'index.html');
                } else if (link.closest('.heart-icon')) {
                    link.setAttribute('href', 'favorites.html');
                } else if (link.closest('.cart-icon')) {
                    link.setAttribute('href', 'cart.html');
                } else if (link.closest('.user-icon')) {
                    link.setAttribute('href', 'login.html');
        } else {
                    link.setAttribute('href', '#');
                }
            }
        });
        
        // إزالة أي عناصر مخفية تغطي الصفحة
        document.querySelectorAll('.modal, .overlay, .product-modal').forEach(el => {
            el.style.display = 'none';
        });
        
        console.log('تم تطبيق إصلاحات التفاعل');
    });
  </script>
  <!-- إصلاح أزرار السلة والمفضلة -->
  <script>
   document.addEventListener('DOMContentLoaded', function() {
        // تفعيل زر السلة
        const cartButtons = document.querySelectorAll('.add-to-cart, .cart-icon');
        cartButtons.forEach(button => {
            // إزالة أي مستمعات أحداث سابقة
            const newButton = button.cloneNode(true);
            button.parentNode.replaceChild(newButton, button);
            
            newButton.addEventListener('click', function(event) {
                event.preventDefault();
                
                // مسار الصفحة حسب نوع الزر
                let targetUrl = 'cart.html';
                
                // توجيه المستخدم للصفحة المناسبة
                window.location.href = targetUrl;
            });
        });
        
        // تفعيل زر المفضلة
        const wishlistButtons = document.querySelectorAll('.wishlist-btn, .heart-icon');
        wishlistButtons.forEach(button => {
            // إزالة أي مستمعات أحداث سابقة
            const newButton = button.cloneNode(true);
            button.parentNode.replaceChild(newButton, button);
            
            newButton.addEventListener('click', function(event) {
                event.preventDefault();
                
                // تغيير أيقونة القلب (إن وجدت)
                const heartIcon = this.querySelector('i');
                if (heartIcon) {
                    if (heartIcon.classList.contains('far')) {
                        heartIcon.classList.remove('far');
                        heartIcon.classList.add('fas');
            } else {
                        heartIcon.classList.remove('fas');
                        heartIcon.classList.add('far');
                    }
                }
                
                // توجيه المستخدم للصفحة المناسبة
                window.location.href = 'favorites.html';
            });
        });
        
        // تصحيح روابط الكاميرات والعدسات والاكسسوارات
        const categoryLinks = {
            'cameras': 'all-cameras.html',
            'lenses': 'all-lenses.html',
            'accessories': 'all-accessories.html',
            'audio': 'all-audio.html',
            'bags': 'all-bags.html'
        };
        
        // تفعيل روابط الفئات
        for (const [category, url] of Object.entries(categoryLinks)) {
            document.querySelectorAll(`.${category}, [data-category="${category}"]`).forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    window.location.href = url;
                });
            });
        }
        
        // تفعيل روابط المنتجات
        document.querySelectorAll('.product-card, .product-link').forEach(product => {
            product.addEventListener('click', function(event) {
                // الحصول على فئة المنتج
                const category = this.dataset.category || 'cameras';
                // توجيه المستخدم لصفحة المنتج
                window.location.href = categoryLinks[category] || 'all-cameras.html';
            });
        });
        
        console.log('تم تفعيل أزرار السلة والمفضلة وروابط المنتجات');
    });
  </script>
  <script>
   document.addEventListener('DOMContentLoaded', function() {
        // 1. توحيد شكل أيقونة القلب في كل الصفحات
        const allHeartIcons = document.querySelectorAll('.add-to-favorites-btn i, .favorite-btn i');
        allHeartIcons.forEach(icon => {
            // إزالة جميع الأصناف لمنع ظهور القلب الفارغ
            icon.className = '';
            // إضافة الصنف الذي يجعل القلب رمادي/رصاصي كامل
            icon.classList.add('fas', 'fa-heart');
            icon.style.color = '#888'; // لون رمادي/رصاصي
        });

        // 2. تفعيل زر المفضلة لجميع المنتجات
        const favButtons = document.querySelectorAll('.add-to-favorites-btn, .favorite-btn');
        
        // تحميل المفضلات المخزنة مسبقاً
        let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        
        // تعيين حالة الأزرار بناءً على المفضلات المخزنة
        favButtons.forEach(btn => {
            // العثور على معرف المنتج
            const productId = btn.getAttribute('data-product-id') || btn.closest('[data-product-id]')?.getAttribute('data-product-id');
            
            if (productId && favorites.includes(productId)) {
                const heartIcon = btn.querySelector('i');
                if (heartIcon) {
                    heartIcon.style.color = 'red';
                }
            }
            
            // إضافة حدث النقر على زر المفضلة
            btn.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                
                const productId = this.getAttribute('data-product-id') || this.closest('[data-product-id]')?.getAttribute('data-product-id');
                const heartIcon = this.querySelector('i');
                
                if (productId && heartIcon) {
                    if (favorites.includes(productId)) {
                        // إزالة من المفضلة
                        favorites = favorites.filter(id => id !== productId);
                        heartIcon.style.color = '#888'; // رمادي
                    } else {
                        // إضافة إلى المفضلة
                        favorites.push(productId);
                        heartIcon.style.color = 'red';
                    }
                    
                    // حفظ المفضلات في localStorage
                    localStorage.setItem('favorites', JSON.stringify(favorites));
                }
            });
        });

        // 3. استبدال عبارة "إضافة إلى السلة" بأيقونة سلة فقط
        const cartButtons = document.querySelectorAll('.add-to-cart-btn');
        cartButtons.forEach(btn => {
            // حفظ الأيقونة الحالية إذا وجدت
            const existingIcon = btn.querySelector('i');
            
            // إزالة جميع المحتويات وإضافة أيقونة السلة فقط
            btn.innerHTML = '';
            
            // إنشاء أيقونة السلة
            const cartIcon = existingIcon || document.createElement('i');
            cartIcon.className = 'fas fa-shopping-cart';
            
            btn.appendChild(cartIcon);
        });

        // 4. إزالة النافذة المنبثقة عند تمرير الماوس على المنتج
        const popups = document.querySelectorAll('.product-popup, .popup-content, .product-modal');
        popups.forEach(popup => {
            popup.style.display = 'none';
        });
    });
  </script>
  <script>
   document.addEventListener('DOMContentLoaded', function() {
        // 1. إضافة أزرار "إضافة للسلة" و"إضافة للمفضلة" لقسم المنتجات الأكثر شيوعًا
        const popularProducts = document.querySelectorAll('.popular-products .product-card');
        popularProducts.forEach((product, index) => {
            if (!product.querySelector('.add-to-cart-btn') && !product.querySelector('.add-to-favorites-btn')) {
                // إنشاء زر السلة إذا لم يكن موجوداً
                const cartBtn = document.createElement('button');
                cartBtn.className = 'add-to-cart-btn';
                cartBtn.setAttribute('data-product-id', `popular-${index}`);
                cartBtn.innerHTML = '<i class="fas fa-shopping-cart"></i>';
                
                // إنشاء زر المفضلة إذا لم يكن موجوداً
                const favBtn = document.createElement('button');
                favBtn.className = 'add-to-favorites-btn';
                favBtn.setAttribute('data-product-id', `popular-${index}`);
                favBtn.innerHTML = '<i class="fas fa-heart"></i>';
                
                // إنشاء حاوية للأزرار إذا لم تكن موجودة
                let actionsDiv = product.querySelector('.product-actions');
                if (!actionsDiv) {
                    actionsDiv = document.createElement('div');
                    actionsDiv.className = 'product-actions';
                    product.appendChild(actionsDiv);
                }
                
                // إضافة الأزرار إلى الحاوية
                actionsDiv.appendChild(cartBtn);
                actionsDiv.appendChild(favBtn);
            }
        });
        
        // 2. تفعيل زر المفضلة لجميع المنتجات
        const favButtons = document.querySelectorAll('.add-to-favorites-btn, .favorite-btn');
        
        // تحميل المفضلات المخزنة مسبقاً
        let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        
        // تطبيق الحالة الأولية على الأزرار
        favButtons.forEach(btn => {
            const productId = btn.getAttribute('data-product-id') || btn.closest('[data-product-id]')?.getAttribute('data-product-id');
            const heartIcon = btn.querySelector('i');
            
            if (heartIcon) {
                // توحيد شكل الأيقونة
                heartIcon.className = 'fas fa-heart';
                
                // تعيين اللون بناءً على حالة المفضلة
                if (productId && favorites.includes(productId)) {
                    heartIcon.style.color = 'red';
                } else {
                    heartIcon.style.color = '#888'; // رمادي
                }
            }
            
            // إضافة حدث النقر
            btn.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                
                const productId = this.getAttribute('data-product-id') || this.closest('[data-product-id]')?.getAttribute('data-product-id');
                const heartIcon = this.querySelector('i');
                
                if (productId && heartIcon) {
                    if (favorites.includes(productId)) {
                        // إزالة من المفضلة
                        favorites = favorites.filter(id => id !== productId);
                        heartIcon.style.color = '#888'; // رمادي
                    } else {
                        // إضافة إلى المفضلة
                        favorites.push(productId);
                        heartIcon.style.color = 'red';
                    }
                    
                    // حفظ المفضلات في localStorage
                    localStorage.setItem('favorites', JSON.stringify(favorites));
                }
            });
        });
        
        // 3. استبدال نص "إضافة إلى السلة" بأيقونة السلة فقط
        const cartButtons = document.querySelectorAll('.add-to-cart-btn');
        cartButtons.forEach(btn => {
            // تحقق مما إذا كان الزر يحتوي على نص
            if (btn.textContent.trim() !== '' && !btn.querySelector('i:only-child')) {
                // حفظ أي أيقونة موجودة
                const existingIcon = btn.querySelector('i');
                
                // تفريغ محتوى الزر
                btn.innerHTML = '';
                
                // إضافة أيقونة السلة فقط
                const cartIcon = existingIcon || document.createElement('i');
                cartIcon.className = 'fas fa-shopping-cart';
                btn.appendChild(cartIcon);
            }
        });
        
        // 4. إزالة النافذة المنبثقة
        const popups = document.querySelectorAll('.product-popup, .popup-content, .product-modal');
        popups.forEach(popup => {
            popup.style.display = 'none';
        });
        
        // إزالة أحداث hover التي قد تظهر النافذة المنبثقة
        const productCards = document.querySelectorAll('.product-card');
        productCards.forEach(card => {
            const clonedCard = card.cloneNode(true);
            card.parentNode.replaceChild(clonedCard, card);
        });
    });
  </script>
  <script>
   // ✅ توحيد شكل أيقونة المفضلة لتكون رمادية بالكامل
    document.querySelectorAll('.fa-heart').forEach(icon => {
      icon.classList.remove('far'); // قلب فاضي
      icon.classList.add('fas');    // قلب ممتلئ
      icon.style.color = '#aaa';    // اللون الرصاصي
    });

    // ✅ تفعيل زر "إضافة للمفضلة"
    document.querySelectorAll('.favorite-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        const productId = this.dataset.id;
        let favorites = JSON.parse(localStorage.getItem('favorites')) || [];

        const icon = this.querySelector('.fa-heart');
        if (favorites.includes(productId)) {
          favorites = favorites.filter(id => id !== productId);
          icon.style.color = '#aaa';
        } else {
          favorites.push(productId);
          icon.style.color = 'red';
        }

        localStorage.setItem('favorites', JSON.stringify(favorites));
      });
    });



    // ✅ إزالة البوب-أب اللي يطلع عند تمرير الماوس والاكتفاء بزر عرض التفاصيل
    document.querySelectorAll('.product-popup').forEach(popup => {
      popup.style.display = 'none'; // بدلاً من إزالة النافذة سنخفيها فقط لعرضها عند النقر على الزر
    });

    // دالة لفتح تفاصيل المنتج
    function openProductDetails(productId) {
        // حفظ معرف المنتج في localStorage
        localStorage.setItem('openProductDetails', productId);
        // الانتقال إلى صفحة الكاميرات
        window.location.href = 'all-cameras.html';
    }
  </script>
