<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!$full_name || !$email || !$password) {
        die("جميع الحقول مطلوبة");
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $verification_code = bin2hex(random_bytes(16));

    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, verification_code) VALUES (?, ?, ?, ?)");
    $stmt->execute([$full_name, $email, $hashed_password, $verification_code]);

    $subject = "تأكيد حسابك";
    $message = "اضغط على الرابط لتأكيد حسابك: http://localhost/verify.php?code=$verification_code";
    $headers = "From: no-reply@example.com";

    mail($email, $subject, $message, $headers);

    echo "تم تسجيل الحساب بنجاح! تحقق من بريدك الإلكتروني لتفعيل الحساب.";
}
?>