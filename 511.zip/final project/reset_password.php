<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $otp = trim($_POST['otp']);
    $new_password = trim($_POST['new_password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND reset_otp = ?");
    $stmt->execute([$email, $otp]);
    $user = $stmt->fetch();

    if ($user) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $conn->prepare("UPDATE users SET password = ?, reset_otp = NULL WHERE id = ?")
             ->execute([$hashed_password, $user['id']]);
        echo "تم تغيير كلمة المرور بنجاح!";
    } else {
        echo "رمز OTP غير صحيح.";
    }
}
?>