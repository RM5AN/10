
-- إضافة صور للمنتجات مع matching product_id
INSERT INTO product_images (product_id, image_url) VALUES
(1, 'images/product1_1.jpg'),
(1, 'images/product1_2.jpg'),
(2, 'images/product2_1.jpg'),
(2, 'images/product2_2.jpg');
