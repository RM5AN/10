let originalProducts = [];
let currentCategory = 'all';

document.addEventListener('DOMContentLoaded', function() {
    try {
        // إزالة النوافذ المنبثقة وتعطيلها
        removePopups();
        
        // انتظار تحميل جميع العناصر
        setTimeout(() => {
            const allProducts = document.querySelectorAll('.product-card, .camera-card');
            if (allProducts.length === 0) {
                console.log('لم يتم العثور على منتجات');
                return;
            }
            
            // التأكد من أن جميع المنتجات تحتوي على سمة data-operation
            allProducts.forEach(card => {
                // إذا لم تكن هناك سمة data-operation، نضيفها بناءً على وجود زر "استئجار" أو "شراء"
                if (!card.hasAttribute('data-operation')) {
                    const rentButton = card.querySelector('.rent-button, .add-to-rent');
                    const buyButton = card.querySelector('.buy-button, .add-to-cart');
                    
                    if (rentButton) {
                        card.setAttribute('data-operation', 'rent');
                    } else if (buyButton) {
                        card.setAttribute('data-operation', 'buy');
                    } else {
                        // إذا لم نجد أي زر، نفترض أنه منتج للشراء
                        card.setAttribute('data-operation', 'buy');
                    }
                }
                
                // التأكد من أن جميع المنتجات تحتوي على سمة data-category
                if (!card.hasAttribute('data-category')) {
                    // تحديد الفئة بناءً على نوع المنتج
                    if (card.classList.contains('camera-card')) {
                        card.setAttribute('data-category', 'cameras');
                    } else {
                        card.setAttribute('data-category', 'accessories');
                    }
                }
            });
            
            console.log('تم تهيئة سمات المنتجات');
            
            originalProducts = Array.from(allProducts).map(card => card.cloneNode(true));

            const filterCategory = document.getElementById('filter-category');
            const filterOperation = document.getElementById('filter-operation');
            const filterSort = document.getElementById('filter-sort');

            function applyFilters() {
                try {
                    const selectedCategory = filterCategory ? filterCategory.value : 'all';
                    currentCategory = selectedCategory; // حفظ الفئة المحددة حالياً
                    
                    const selectedOperation = filterOperation ? filterOperation.value : 'all';
                    const selectedSort = filterSort ? filterSort.value : 'default';

                    console.log('الفئة المحددة:', selectedCategory);
                    console.log('نوع العملية المحدد:', selectedOperation);

                    let filteredProducts = originalProducts.filter(card => {
                        // فلترة حسب الفئة
                        const matchesCategory = (selectedCategory === 'all') || (card.dataset.category === selectedCategory);
                        
                        // فلترة حسب نوع العملية (شراء/استئجار)
                        let matchesOperation = true;
                        if (selectedOperation !== 'all') {
                            // الحصول على نوع العملية من سمة data-operation
                            const operationType = card.getAttribute('data-operation') || '';
                            console.log('نوع العملية للمنتج:', operationType);
                            
                            if (selectedOperation === 'buy') {
                                // إذا تم اختيار "شراء"، نستبعد منتجات الاستئجار
                                matchesOperation = operationType !== 'rent';
                            } else if (selectedOperation === 'rent') {
                                // إذا تم اختيار "استئجار"، نعرض فقط منتجات الاستئجار
                                matchesOperation = operationType === 'rent';
                            }
                        }
                        
                        return matchesCategory && matchesOperation;
                    });

                    console.log('عدد المنتجات المفلترة:', filteredProducts.length);

                    if (selectedSort === 'high-to-low') {
                        filteredProducts.sort((a, b) => {
                            const priceA = parseFloat(a.querySelector('.price')?.textContent?.replace(/[^\d.]/g, '') || '0');
                            const priceB = parseFloat(b.querySelector('.price')?.textContent?.replace(/[^\d.]/g, '') || '0');
                            return priceB - priceA;
                        });
                    } else if (selectedSort === 'low-to-high') {
                        filteredProducts.sort((a, b) => {
                            const priceA = parseFloat(a.querySelector('.price')?.textContent?.replace(/[^\d.]/g, '') || '0');
                            const priceB = parseFloat(b.querySelector('.price')?.textContent?.replace(/[^\d.]/g, '') || '0');
                            return priceA - priceB;
                        });
                    }

                    showPage(1, filteredProducts);
                    updatePagination(filteredProducts, selectedCategory);
                } catch (error) {
                    console.error('خطأ في تطبيق الفلاتر:', error);
                }
            }

            if (filterCategory) filterCategory.addEventListener('change', applyFilters);
            if (filterOperation) filterOperation.addEventListener('change', applyFilters);
            if (filterSort) filterSort.addEventListener('change', applyFilters);

            applyFilters();
        }, 100);
    } catch (error) {
        console.error('خطأ في تهيئة صفحة المنتجات:', error);
    }
});

// دالة لإزالة النوافذ المنبثقة وتعطيلها
function removePopups() {
    try {
        // تحقق إذا كانت الصفحة الحالية هي الصفحة الرئيسية
        const isHomePage = window.location.pathname.includes('index.html') || 
                          window.location.pathname === '/' || 
                          window.location.pathname.endsWith('/');
        
        // في الصفحة الرئيسية، نحتفظ بالنوافذ المنبثقة للمنتجات الأكثر شيوعًا
        if (isHomePage) {
            // لا نحذف النوافذ المنبثقة للمنتجات الأكثر شيوعًا
            // فقط نضيف مستمعات الأحداث للأزرار
            
            // إضافة مستمعات لأزرار عرض المنتج
            document.querySelectorAll('.view-product-btn').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // البحث عن النافذة المنبثقة الأقرب
                    const card = this.closest('.popular-card');
                    if (card) {
                        const popup = card.querySelector('.product-popup');
                        if (popup) {
                            // إضافة فئة 'active' للنافذة المنبثقة لإظهارها
                            popup.classList.add('active');
                            
                            // إنشاء طبقة تظليل إذا لم تكن موجودة
                            let overlay = document.querySelector('.popup-overlay');
                            if (!overlay) {
                                overlay = document.createElement('div');
                                overlay.className = 'popup-overlay';
                                document.body.appendChild(overlay);
                            }
                            overlay.classList.add('active');
                        }
                    }
                });
            });
            
            // إضافة مستمعات لأزرار إغلاق النوافذ المنبثقة
            document.querySelectorAll('.popup-close').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // البحث عن النافذة المنبثقة الأقرب
                    const popup = this.closest('.product-popup');
                    if (popup) {
                        popup.classList.remove('active');
                        document.querySelector('.popup-overlay')?.classList.remove('active');
                    }
                });
            });
            
            console.log('تم تفعيل النوافذ المنبثقة للمنتجات الأكثر شيوعًا في الصفحة الرئيسية');
        } else {
            // في الصفحات الأخرى، نزيل جميع النوافذ المنبثقة
            // إزالة جميع العناصر المنبثقة من الصفحة
            const popups = document.querySelectorAll('.product-popup, .popup-content, .product-modal');
            popups.forEach(popup => {
                popup.remove();
            });

            // تعديل أزرار "أضف إلى السلة" لإظهار الأيقونة فقط
            document.querySelectorAll('.add-to-cart, .add-to-cart-btn').forEach(button => {
                // حفظ الرمز فقط وإزالة النص
                const icon = button.querySelector('i') || document.createElement('i');
                if (!icon.classList.contains('fas')) {
                    icon.className = 'fas fa-shopping-cart';
                }
                button.innerHTML = '';
                button.appendChild(icon);
                button.title = 'أضف إلى السلة';
                
                // تعديل الشكل ليناسب حجم الأيقونة فقط
                button.style.width = '36px';
                button.style.height = '36px';
                button.style.borderRadius = '50%';
                button.style.display = 'flex';
                button.style.alignItems = 'center';
                button.style.justifyContent = 'center';
                
                // منع فتح النافذة المنبثقة عند النقر
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                });
            });
            
            // التأكد من وجود زر "عرض التفاصيل" لكل منتج
            document.querySelectorAll('.product-card, .camera-card, .popular-card').forEach(card => {
                let viewDetailsBtn = card.querySelector('.view-details-btn');
                
                // إذا لم يكن هناك زر، نقوم بإنشائه
                if (!viewDetailsBtn) {
                    const actionsContainer = card.querySelector('.product-actions') || 
                                             card.querySelector('.card-actions') || 
                                             card.querySelector('.action-buttons');
                    
                    if (actionsContainer) {
                        viewDetailsBtn = document.createElement('a');
                        viewDetailsBtn.className = 'view-details-btn';
                        viewDetailsBtn.innerHTML = '<i class="fas fa-eye"></i> عرض التفاصيل';
                        viewDetailsBtn.href = 'product-details.html?id=' + (card.dataset.id || '1');
                        actionsContainer.appendChild(viewDetailsBtn);
                    }
                }
            });
            
            console.log('تم إزالة وتعطيل النوافذ المنبثقة بنجاح');
        }
        
        // إضافة أنماط CSS للنوافذ المنبثقة إذا لم تكن موجودة
        if (!document.getElementById('product-popup-styles')) {
            const style = document.createElement('style');
            style.id = 'product-popup-styles';
            style.textContent = `
                .popup-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0,0,0,0.5);
                    z-index: 9999;
                    display: none;
                }
                
                .popup-overlay.active {
                    display: block;
                }
                
                .product-popup {
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background-color: white;
                    border-radius: 10px;
                    box-shadow: 0 5px 25px rgba(0,0,0,0.2);
                    z-index: 10000;
                    width: 90%;
                    max-width: 500px;
                    padding: 20px;
                    max-height: 90vh;
                    overflow-y: auto;
                    display: none;
                }
                
                .product-popup.active {
                    display: block;
                }
            `;
            document.head.appendChild(style);
            
            // إنشاء طبقة تظليل للنوافذ المنبثقة إذا لم تكن موجودة
            if (!document.querySelector('.popup-overlay')) {
                const overlay = document.createElement('div');
                overlay.className = 'popup-overlay';
                document.body.appendChild(overlay);
                
                // إضافة مستمع حدث للنقر على طبقة التظليل لإغلاق النوافذ المنبثقة
                overlay.addEventListener('click', function() {
                    const activePopup = document.querySelector('.product-popup.active');
                    if (activePopup) {
                        activePopup.classList.remove('active');
                        this.classList.remove('active');
                    }
                });
            }
        }
    } catch (error) {
        console.error('حدث خطأ أثناء تعديل النوافذ المنبثقة:', error);
    }
}

function showPage(page, visibleProducts) {
    const start = (page - 1) * 8;
    const end = start + 8;
    const productsToShow = visibleProducts.slice(start, end);

    console.log('عرض الصفحة:', page);
    console.log('عدد المنتجات في هذه الصفحة:', productsToShow.length);

    const productsGrid = document.querySelector('.products-grid, .product-grid, .cameras-grid');
    if (!productsGrid) {
        console.error('لم يتم العثور على عنصر شبكة المنتجات');
        return;
    }

    productsGrid.innerHTML = '';

    if (productsToShow.length === 0) {
        const noProductsMessage = document.createElement('div');
        noProductsMessage.textContent = 'لا توجد منتجات متاحة في هذه الصفحة';
        noProductsMessage.style.textAlign = 'center';
        noProductsMessage.style.marginTop = '20px';
        noProductsMessage.style.color = '#666';
        noProductsMessage.style.fontSize = '16px';
        productsGrid.appendChild(noProductsMessage);
        return;
    }

    productsToShow.forEach(card => {
        const clonedCard = card.cloneNode(true);
        productsGrid.appendChild(clonedCard);
    });
}

function updatePagination(visibleProducts, selectedCategory) {
    const pagination = document.querySelector('.pagination');
    if (!pagination) return;

    pagination.innerHTML = '';

    const productsPerPage = 8;
    const totalPages = Math.ceil(visibleProducts.length / productsPerPage);

    // إذا لم تكن هناك منتجات، نعرض رسالة
    if (visibleProducts.length === 0) {
        const noProductsMessage = document.createElement('div');
        noProductsMessage.textContent = 'لا توجد منتجات متاحة في هذه الفئة';
        noProductsMessage.style.textAlign = 'center';
        noProductsMessage.style.marginTop = '20px';
        noProductsMessage.style.color = '#666';
        noProductsMessage.style.fontSize = '16px';
        
        const productsGrid = document.querySelector('.products-grid, .product-grid, .cameras-grid');
        if (productsGrid) {
            productsGrid.innerHTML = '';
            productsGrid.appendChild(noProductsMessage);
        }
        return;
    }

    // إنشاء أزرار الترقيم
    for (let page = 1; page <= totalPages; page++) {
        const button = document.createElement('button');
        button.textContent = page;
        button.classList.add('page-btn');
        
        // حساب المنتجات في هذه الصفحة
        const startIndex = (page - 1) * productsPerPage;
        const pageProducts = visibleProducts.slice(startIndex, startIndex + productsPerPage);
        
        // التحقق مما إذا كانت الصفحة تحتوي على منتجات من الفئة المحددة
        const hasProductsInCategory = selectedCategory === 'all' || 
            pageProducts.some(product => product.dataset.category === selectedCategory);
        
        if (!hasProductsInCategory) {
            button.disabled = true;
            button.style.opacity = '0.5';
            button.style.cursor = 'not-allowed';
        } else {
            button.addEventListener('click', function() {
                document.querySelectorAll('.page-btn').forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                showPage(page, visibleProducts);
            });
        }
        
        // تحديد الزر النشط
        if (page === 1) {
            button.classList.add('active');
        }

        pagination.appendChild(button);
    }
}
