
<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $confirm_password = trim($_POST["confirm_password"]);

    if (empty($full_name) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "جميع الحقول مطلوبة!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "البريد الإلكتروني غير صالح!";
    } elseif ($password !== $confirm_password) {
        echo "كلمتا المرور غير متطابقتين!";
    } else {
        // تحقق إذا البريد الإلكتروني موجود
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            echo "البريد الإلكتروني مستخدم مسبقاً!";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
            $insert_stmt->bind_param("sss", $full_name, $email, $hashed_password);

            if ($insert_stmt->execute()) {
                echo "تم إنشاء الحساب بنجاح!";
            } else {
                echo "حدث خطأ أثناء إنشاء الحساب.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل حساب جديد</title>
</head>
<body>
    <h2>تسجيل حساب جديد</h2>
    <form action="register.php" method="post">
        <label>الاسم الكامل:</label><br>
        <input type="text" name="full_name" required><br><br>
        <label>البريد الإلكتروني:</label><br>
        <input type="email" name="email" required><br><br>
        <label>كلمة المرور:</label><br>
        <input type="password" name="password" required><br><br>
        <label>تأكيد كلمة المرور:</label><br>
        <input type="password" name="confirm_password" required><br><br>
        <input type="submit" value="تسجيل">
    </form>
</body>
</html>
