/**
 * شريط البحث الفوري - ShotSpot
 * يوفر وظيفة البحث الفوري في المنتجات
 */

// عند تحميل المستند بالكامل
document.addEventListener('DOMContentLoaded', function() {
    setupSearch();
});

// إعداد وظيفة البحث
function setupSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    
    // التأكد من وجود عناصر البحث في الصفحة
    if (!searchInput || !searchResults) return;
    
    // تحميل بيانات المنتجات
    const allProducts = getAllProducts();
    
    // عند الكتابة في حقل البحث
    searchInput.addEventListener('input', function() {
        const query = this.value.trim().toLowerCase();
        
        // إظهار النتائج فقط إذا كان هناك نص في حقل البحث
        if (query.length < 2) {
            searchResults.style.display = 'none';
            return;
        }
        
        // البحث في المنتجات
        const filteredProducts = allProducts.filter(product => 
            product.name.toLowerCase().includes(query)
        );
        
        // عرض النتائج
        displaySearchResults(filteredProducts, query);
    });
    
    // إخفاء نتائج البحث عند النقر خارجها
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
}

// الحصول على بيانات جميع المنتجات
function getAllProducts() {
    // يمكن تحديث هذه الدالة لتحميل المنتجات من API أو localStorage
    // حاليًا تستخدم بيانات وهمية للتجربة
    return [
        { id: 1, name: 'كاميرا سوني Alpha 7 III', price: '٧,٩٩٩ ريال', image: 'https://via.placeholder.com/150?text=Sony' },
        { id: 2, name: 'كاميرا كانون EOS 5D Mark IV', price: '٩,٥٩٩ ريال', image: '4549292204889 R8 camera (1)-432x432.jpg' },
        { id: 3, name: 'عدسة سيغما 24-70mm', price: '٣,٢٩٩ ريال', image: 'sigma 24-70 (1).jpg' },
        { id: 4, name: 'عدسة كانون RF24-105mm', price: '٤,٥٩٩ ريال', image: 'canon RF24-105mm (1).jpg' },
        { id: 5, name: 'حقيبة Lowepro ProTactic 450 AW II', price: '٧٩٩ ريال', image: 'Lowepro ProTactic 450 AW II (1).jpg' },
        { id: 6, name: 'حقيبة Think Tank Airport Security', price: '١,٢٩٩ ريال', image: 'Think Tank Airport Security V3.0 (1).jpg' },
        { id: 7, name: 'فلاش Godox WB87', price: '٥٩٩ ريال', image: 'Godox WB87 (1).jpg' },
        { id: 8, name: 'مسجل صوتي Zoom H5', price: '١,١٩٩ ريال', image: 'Zoom H5 Handy Recorder (1).jpg' },
        { id: 9, name: 'حامل كاميرا ثلاثي', price: '٢٩٩ ريال', image: 'Camera Tripod Stand 170cm (1).jpg' },
        { id: 10, name: 'سماعات Beyerdynamic DT 770 Pro', price: '٨٩٩ ريال', image: 'Beyerdynamic DT 770 Pro (1).jpg' },
        { id: 11, name: 'فلتر K&F Concept 77mm', price: '١٩٩ ريال', image: 'Filter,K&F Concept 77mm (1).jpg' },
        { id: 12, name: 'عدسة تامرون Tamron 17-70mm', price: '٢,٩٩٩ ريال', image: 'Tamron 17-70mm (1).jpg' }
    ];
}

// عرض نتائج البحث
function displaySearchResults(products, query) {
    const searchResults = document.getElementById('searchResults');
    
    if (products.length === 0) {
        searchResults.innerHTML = '<div class="no-results">لا توجد نتائج مطابقة</div>';
    } else {
        let html = '<ul>';
        products.forEach(product => {
            html += `
                <li onclick="goToProductPage(${product.id})">
                    <img src="${product.image}" alt="${product.name}" onerror="this.src='https://via.placeholder.com/150?text=ShotSpot'">
                    <div class="result-info">
                        <h4>${highlightText(product.name, query)}</h4>
                        <p>${product.price}</p>
                    </div>
                </li>
            `;
        });
        html += '</ul>';
        searchResults.innerHTML = html;
    }
    
    searchResults.style.display = 'block';
}

// تمييز نص البحث في النتائج
function highlightText(text, query) {
    if (!query) return text;
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<span style="background-color: #FFFF99;">$1</span>');
}

// الانتقال إلى صفحة المنتج
function goToProductPage(productId) {
    // يمكن تعديل هذا المسار حسب هيكل الموقع
    window.location.href = `product.html?id=${productId}`;
} 