// إضافة منتج للسلة
function addToCart(productId) {
    fetch('/api/cart/add/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: 1
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('تمت إضافة المنتج إلى السلة', 'success');
            updateCartCount(data.cart_count);
        }
    });
}

// إضافة/إزالة منتج من المفضلة
function toggleWishlist(productId) {
    fetch('/api/wishlist/toggle/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({
            product_id: productId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const btn = document.querySelector(`.wishlist-btn[data-product-id="${productId}"] i`);
            btn.classList.toggle('fas');
            btn.classList.toggle('far');
            showToast(data.in_wishlist ? 'تمت إضافة المنتج للمفضلة' : 'تمت إزالة المنتج من المفضلة', 'success');
        }
    });
}

// البحث عن المنتجات
function searchProducts(query) {
    fetch(`/api/products/search/?q=${encodeURIComponent(query)}`)
    .then(response => response.json())
    .then(data => {
        // تحديث نتائج البحث في الواجهة
        updateSearchResults(data.products);
    });
}

// إضافة مستمعات الأحداث
document.addEventListener('DOMContentLoaded', () => {
    // أزرار السلة
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const productId = e.target.closest('[data-product-id]').dataset.productId;
            addToCart(productId);
        });
    });

    // أزرار المفضلة
    document.querySelectorAll('.wishlist-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const productId = e.target.closest('[data-product-id]').dataset.productId;
            toggleWishlist(productId);
        });
    });

    // حقل البحث
    const searchInput = document.querySelector('.search-container input');
    if (searchInput) {
        searchInput.addEventListener('input', debounce((e) => {
            searchProducts(e.target.value);
        }, 300));
    }
}); 